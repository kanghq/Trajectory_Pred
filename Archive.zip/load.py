import pandas as pd
import numpy as np
import datetime

def loadFile(path):
    dateparse = lambda x: pd.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')
    with open(path) as f:
        for _ in range(6):
            next(f)
        data = pd.read_csv(f,usecols=[0,1,5,6],names = ["lat","long","date","time"], parse_dates={'datetime': ['date', 'time']},date_parser=dateparse)
        #dateCol = data.loc[:,5]
        #timeCol = data.loc[:,6]
        #dateTimeCol = dateCol.str.cat(timeCol,sep='_')
        #dateTimeSet = set(dateTimeCol.str[0:16])
        recordsDF = pd.DataFrame(columns=[0,1,5,6])
        #for timeSlot in dateTimeSet:
        #    record = data[data.loc[:,5].str.contains(timeSlot[:10])&data.loc[:,6].str.contains(timeSlot[11:])].head(1)
        #    if(record is not None):
        #        recordsDF = recordsDF.append(record, ignore_index=True)
        #        continue

        #recordsDF = recordsDF.sort_values(by=[5,6])
        #recordsDF = recordsDF.reset_index(drop=True)
        data = data.sort_values(by=['datetime'])
        data = data.reset_index(drop=True)
        diffdata = data.diff()
        diffdata.loc[0] = data.loc[0]
        diffdata.iloc[0,0] = data.loc[0][0]-datetime.datetime(1980,1,1)
        #diffdata.index = diffdata.index+1
        #diffdata.sort_index(inplace=True)
        diffdata['datetime'] = pd.to_timedelta(diffdata['datetime']).dt.seconds
        #data = data.fillna(0)
        #return diffdata
        nparr = np.array(diffdata.values.tolist(),ndmin=2)
        return(nparr)

def getRowNumber(lat,bottomBound, topBound, height,step):
    if(lat>topBound):
        return step-1
    if(lat<bottomBound):
        return 0
    return int((lat-bottomBound)/height)

def getColNumber(long,leftBound, rightBound, width,step):
    if(long>rightBound):
        return step-1
    if(long<leftBound):
        return 0
    return int((long-leftBound)/width)

def getCellNum(lat,long,leftBound,rightBound,bottomBound,topBound,width,height,step):
    col = getColNumber(long,leftBound,rightBound,width,step)
    row = getRowNumber(lat,bottomBound,topBound,height,step)
    seq = (row-1)*step+col
    if( seq <0):
        return 0
    if(seq > step*step-1):
        return step*step-1
    return seq

def df2oneHotMatrix(dataFrame,leftBound,rightBound,bottomBound,topBound,step):
    cellWidth = (rightBound-leftBound)/step
    cellHeight = (topBound-bottomBound)/step
    locationDF = dataFrame.apply(lambda x: getCellNum(x[0],x[1],leftBound,rightBound,bottomBound,topBound,cellWidth,cellHeight,step),axis=1)#.to_frame()
    #oneHotSer = locationDF.apply(lambda x: oneHotEnc(x[0],step),axis =1)

    #return oneHotSer
    return locationDF

# def convertTimeStamp2Step(dataFrame):



def oneHotEnc(num, step):
    vector = [0 for _ in range(step*step)]
    vector[num] = 1
    return vector

def loadn2HotMatrix(path,leftBound,rightBound,bottomBound,topBound,step):
    df = loadFile(path)
    return df2oneHotMatrix(df,leftBound,rightBound,bottomBound,topBound,step)

if __name__ == "__main__":
    df = loadFile('/Users/kanghuaqiang/Downloads/Geolife Trajectories 1.3/Data/181/Trajectory/20071207100605.plt')
    print(df)
    #print(df2oneHotMatrix(df,116.1,116.6,39.7,40.1,500))