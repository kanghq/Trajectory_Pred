import sys
import pandas as pd
import load
import math
import numpy as np
import itertools

import os
from keras.models import Model
from keras.layers import Input, LSTM, Dense

root_folder = sys.argv[1]
suffix_name = '.plt'
fileList = []

def getFileList(folder, list):
    for name in os.listdir(folder):
        if os.path.isdir(os.path.join(folder, name)):
            getFileList(os.path.join(folder, name), list)
        elif name.endswith(suffix_name):
            list.append(os.path.join(folder, name))


getFileList(root_folder,fileList)

steps = 500
latent_dim = 256
input_dim = 2
output_dim = 2


series = list(map(load.loadFile,fileList))
#fill = np.ndarray(list(itertools.zip_longest(*series, fillvalue=0))).T
fill = np.ndarray(series)
print(fill.shape)
#
#
# series = fileDF.apply(lambda x: load.loadn2HotMatrix(x['col'],116.1,116.6,39.7,40.1,steps), axis=1)
#
# matrix = series.values
# onehot = (np.arange(steps*steps) == matrix[...,None]-1).astype(int)


#
# print(onehot[-1,-1,:])
#
#
# encoder_inputs = Input(shape=(None, input_dim))
# encoder = LSTM(latent_dim, return_state=True)
# encoder_outpus, state_h, state_c = encoder(encoder_inputs)
#
# encoder_states = [state_h, state_c]
#
# decoder_inputs = Input(shape=(None, output_dim))
# decoder_lstm = LSTM(latent_dim, return_sequences=True, return_state=True)
# decoder_outputs, _, _ = decoder_lstm(decoder_inputs, initial_state=encoder_states)
#
# decoder_dense = Dense(output_dim)
# decoder_outputs = decoder_dense(decoder_outputs)
#
# model = Model([encoder_inputs, decoder_inputs], decoder_outputs)
#
# model.compile(optimizer='adam', loss='mean_square_error') #Nadam
# model.fit([encoder_input_data ,decoder_input_data], decoder_target_data,
#           batch_size=batch_size,
#           epochs=epochs,
#           validation_split=0.2)
#
# model.save('s2s.h5')

# inference model
#
# encoder_model = Model(encoder_inputs, encoder_states)
#
# decoder_state_input_h = Input(shape=(latent_dim,))
# decoder_state_input_c = Input(shape=(latent_dim,))
# decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]
# decoder_outputs, state_h, state_c = decoder_lstm(decoder_inputs, initial_state=decoder_states_inputs)
# decoder_states = [state_h, state_c]
# decoder_outputs = decoder_dense(decoder_outputs)
# decoder_model = Model(
#     [decoder_inputs] + decoder_states_inputs,
#     [decoder_outputs] + decoder_states)



# fileNameQueue = tf.train.slice_input_producer(fileList)
# reader = tf.TextLineReader(skip_header_lines=6)
#
# print fileList
#
# fileKey, fileVal = reader.read(fileNameQueue)
# record_defaults = [[1.0], [1.0],[1.0],[1.0],[1.0],["Nah"],["Nah"]]
#
# col1, col2 ,col3,col4,col5,col6,col7= tf.decode_csv(fileVal, record_defaults=record_defaults)
#
#
# ta = tf.zeros((2,2))
# with tf.Session() as sess:
#     coord = tf.train.Coordinator()
#     threads = tf.train.start_queue_runners(coord=coord)
#     for i in range(10):
#         example, label = sess.run([col1, col2])
#         print(example,label)
#
#     coord.request_stop()
#     coord.join(threads)
#
